package com.example.motoresapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
